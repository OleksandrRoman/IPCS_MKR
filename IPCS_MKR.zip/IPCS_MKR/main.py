import math, time, random


def find_reverse(a, m):
    k = -1
    b = 1
    while (a * b) % m != 1:
        k += 1
        b = math.ceil(k * m / a)
    return b


def encryptAffine(message, a, b):
    encrypted_message = ""
    for symbol in message:
        if symbol in alphabet:
            encrypted_message += alphabet[(alphabet.index(symbol) * a + b) % len(alphabet)]
        else:
            encrypted_message += symbol
    return encrypted_message


def decryptAffine(message, a, b):
    decrypted_message = ""
    for symbol in message:
        if symbol in alphabet:
            decrypted_message += alphabet[(find_reverse(a, len(alphabet)) * (alphabet.index(symbol) + len(alphabet) - b)) % len(alphabet)]
        else:
            decrypted_message += symbol
    return decrypted_message


def breakAffine(message):
    decrypted_message = ""
    for a in keys:
        for b in range(len(alphabet)):
            for symbol in message:
                if symbol in alphabet:
                    decrypted_message += alphabet[(find_reverse(a, len(alphabet)) * (alphabet.index(symbol) + len(alphabet) - b)) % len(alphabet)]
                else:
                    decrypted_message += symbol
    return


alphabet = "ячсмитьбюфівапролджєїхзщшгнекуцйґЯЧСМИТЬБЮФІВАПРОЛДЖЄЙЦУКЕНГШЩЗХЇҐ"
keys = [1, 3, 5, 7, 9, 11, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65]
key11 = random.choice(keys)
key12 = random.randint(0, len(alphabet))

file1 = open("Text.txt", 'r', 1, 'utf-8')
text = file1.read()
file1.close()
print("Вихідний текст: \n{}".format(text))

start_encrypting = time.time()
text_encrypted = encryptAffine(text, key11, key12)
finish_encrypting = time.time() - start_encrypting
print("\nЗакодований текст: \n{}".format(text_encrypted))

file2 = open("TextEncrypted.txt", "w")
file2.write(text_encrypted)
file2.close()

start_decrypting = time.time()
text_decrypted = decryptAffine(text_encrypted, key11, key12)
finish_decrypting = time.time() - start_decrypting
print("\nРозкодований текст: \n{}".format(text_decrypted))

startBreaking = time.time()
breakAffine(text_encrypted)
finishBreaking = time.time() - startBreaking

print("\nЧас кодування = {}\n"
      "Час декодування = {}\n"
      "Час злому = {}".format(finish_encrypting, finish_decrypting, finishBreaking))
